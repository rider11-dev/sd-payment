Get-ChildItem . | ForEach-Object -Process {
    if ($_ -is [System.IO.DirectoryInfo]) {
        $bin = $_.FullName + "\bin";
        if (Test-Path $bin) {
            Write-Host("remove " + $bin);
            Remove-Item $bin -Recurse -Force
        }
        
        $obj = $_.FullName + "\obj";
        if (Test-Path $obj) {
            Write-Host("remove " + $obj);
            Remove-Item $obj -Recurse -Force
        }
        
        $vs = $_.FullName + "\.vs";
        if (Test-Path $vs) {
            Write-Host("remove " + $vs);
            Remove-Item $vs -Recurse -Force
        }
    }
}