﻿
namespace payfun.dotnet.asp.netcore
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Filters;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Options;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class ExceptionFilter : ExceptionFilterAttribute
    {
        private IAggregateLogger Logger;
        private IHostEnvironment HostEnvironment;
        private AppInfoOption appInfoOption;

        public ExceptionFilter(IAggregateLogger logger,
            IHostEnvironment hostEnvironment,
            IOptions<AppInfoOption> appInfoOption)
        {
            this.HostEnvironment = hostEnvironment;
            this.Logger = logger;
            this.appInfoOption = appInfoOption.Value ?? throw new ArgumentException("请注入App信息");
        }
        public override void OnException(ExceptionContext context)
        {
            if (context.Exception is PayfunMessage message)
            {
                context.ExceptionHandled = true;
                context.Result = new JsonResult(message.ToHttpResult());
            }

            if (context.Exception is Exception exception)
            {

                Logger.Write(appInfoOption.Application, context.Exception.Message, 2, context.Exception.StackTrace.ToString());

                context.ExceptionHandled = true;

                if (this.HostEnvironment.IsDevelopmentOrDev() || this.HostEnvironment.IsFat())
                {
                    context.Result = new JsonResult(HttpResult.Error(msg: exception.ToString()));
                }
                else
                {
                    context.Result = new JsonResult(HttpResult.Error(msg: "发生错误,该错误被记录,请您重试"));
                }
            }
        }
        public override Task OnExceptionAsync(ExceptionContext context)
        {
            if (context.Exception is PayfunMessage message)
            {
                context.ExceptionHandled = true;
                context.Result = new JsonResult(message.ToHttpResult());
            }

            if (context.Exception is Exception exception)
            {

                Logger.Write(appInfoOption.Application, context.Exception.Message, 2, context.Exception.StackTrace.ToString());

                context.ExceptionHandled = true;
                if (this.HostEnvironment.IsDevelopmentOrDev() || this.HostEnvironment.IsFat())
                {
                    context.Result = new JsonResult(HttpResult.Error(msg: exception.ToString()));
                }
                else
                {
                    context.Result = new JsonResult(HttpResult.Error(msg: "发生错误,该错误被记录,请您重试"));
                }

            }

            return Task.CompletedTask;
        }
    }



}
