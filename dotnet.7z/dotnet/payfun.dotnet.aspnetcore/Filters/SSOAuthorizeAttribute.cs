﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Security.Cryptography;
using System.Text;

namespace payfun.dotnet.asp.netcore
{
    /// <summary>
    /// SSO权限拦截器
    /// </summary>
    public class SSOAuthorizeAttribute : ActionFilterAttribute
    {
        private readonly TokenUser tokenUser;
        private readonly IConfiguration configuration;
        private readonly Kind[] _KindArray;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tokenUser"></param>
        /// <param name="configuration"></param>
        /// <param name="permissions"></param>
        public SSOAuthorizeAttribute(TokenUser tokenUser, IConfiguration configuration, Kind[] permissions = null)
        {
            this.tokenUser = tokenUser;
            this.configuration = configuration;
            _KindArray = permissions ?? new Kind[] { };
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            try
            {
                var strtoken = context.HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
                if (string.IsNullOrEmpty(strtoken))
                {
                    context.Result = new JsonResult(new { code = 401, message = "token不能为空" });
                    return;
                }
                else
                {
                    var key = configuration.GetSection("sso_aes_public_key").Get<string>();
                    var user = AnalysisToken(strtoken, key);
                    if (user == null)
                    {
                        context.Result = new JsonResult(new { code = 401, message = "token无效" });
                        return;
                    }
                    if (user.tokenTimeOut < DateTime.UtcNow)
                    {
                        context.Result = new JsonResult(new { code = 401, message = "token已过期" });
                        return;
                    }
                    if (_KindArray.Contains(c => c == Kind.dsp_ad_master_user))
                    {
                        tokenUser.openId = user.openId;
                        tokenUser.token = user.token;
                        tokenUser.kind = user.kind;
                        tokenUser.phone = user.phone;
                        tokenUser.tokenTimeOut = user.tokenTimeOut;
                        tokenUser.areaCode = user.areaCode;
                        base.OnActionExecuting(context);
                    }
                    else
                    {
                        if (!Jurisdiction(user, _KindArray) && _KindArray.Length > 0)
                        {
                            context.Result = new JsonResult(new { code = 401, message = "当前账户没有权限" });
                            return;
                        }
                        else
                        {
                            tokenUser.openId = user.openId;
                            tokenUser.token = user.token;
                            tokenUser.kind = user.kind;
                            tokenUser.phone = user.phone;
                            tokenUser.tokenTimeOut = user.tokenTimeOut;
                            tokenUser.areaCode = user.areaCode;
                            base.OnActionExecuting(context);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                context.Result = new JsonResult(new { code = 401, message = "token异常,权限判断 解析tonken异常:" + ex.ToString() });
                return;
            }
        }
        #region 解密token
        public TokenUser AnalysisToken(string strToken, string key)
        {
            TokenUser user = null;
            try
            {
                if (string.IsNullOrEmpty(strToken) || strToken.Length == 0)
                    return null;
                string strTokenData = AESSecurityHelper.AesDecrypt(strToken, key);
                user = JsonConvert.DeserializeObject<TokenUser>(strTokenData);
                user.token = strToken;

                return user;
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
        #region 判断用户角色
        public bool Jurisdiction(TokenUser token, Kind[] kindArray)
        {
            bool bJuris = false;

            foreach (Kind k in kindArray)
            {
                string KindString = "";
                switch (k)
                {
                    case Kind.dncuser:
                        KindString = "dncuser";
                        break;
                    case Kind.dsp_ad_master_user:
                        KindString = "dsp_ad_master_user";
                        break;
                    case Kind.dsp_ad_agent_user:
                        KindString = "dsp_ad_agent_user";
                        break;
                    case Kind.dsp_ad_ops_user:
                        KindString = "dsp_ad_ops_user";
                        break;
                    case Kind.ad_provider_sp_user:
                        KindString = "ad_provider_sp_user";
                        break;
                    case Kind.merchant_user:
                        KindString = "merchant_user";
                        break;
                    case Kind.sa:
                        KindString = "sa";
                        break;
                    default:
                        break;
                }
                if (token.kind.Contains(KindString))
                {
                    bJuris = true;
                    break;
                }
            }
            return bJuris;
        }
        #endregion
    }
    #region Kind
    public enum Kind
    {
        /// <summary>
        /// 内管人员如:派盟管理员
        /// </summary>
        dncuser = 1,
        /// <summary>
        /// 广告主账号
        /// </summary>
        dsp_ad_master_user = 2,
        /// <summary>
        /// 广告代理账户
        /// </summary>
        dsp_ad_agent_user = 4,
        /// <summary>
        /// 广告运营商
        /// </summary>
        dsp_ad_ops_user = 8,
        /// <summary>
        /// 广告流量方/服务商
        /// </summary>
        ad_provider_sp_user = 16,
        /// <summary>
        /// 商户账户
        /// </summary>
        merchant_user = 32,
        /// <summary>
        /// 超级管理员
        /// </summary>
        sa = 64,
        /// <summary>
        /// 开放平台
        /// </summary>
        open = 128
    }
    #endregion
    #region TokenUser
    public class TokenUser
    {
        public string openId { get; set; }
        public string kind { get; set; }
        public DateTime tokenTimeOut { get; set; }
        public string areaCode { get; set; } = "";
        public string phone { get; set; } = "";
        public string token { get; set; } = "";
    }
    #endregion
    #region AESSecurityHelper
    public static class AESSecurityHelper
    {
        public static string m_key = "fxY9kgb1CpuOWMUt0ozsw6CmVhaC4NA5iuIN04JIabq4TS8eNzbLC4fO6spPaOpEqtskakzQ9KTr5kMSU0ZmouR3UFWVPRxFwRoqlN5cikJHdH3SpQnd0Q07MSMEybA8";
        #region AES加密解密 
        private static byte[] GetAesKey(byte[] keyArray, string key)
        {
            byte[] newArray = new byte[16];
            if (keyArray.Length < 16)
            {
                for (int i = 0; i < newArray.Length; i++)
                {
                    if (i >= keyArray.Length)
                    {
                        newArray[i] = 0;
                    }
                    else
                    {
                        newArray[i] = keyArray[i];
                    }
                }
            }
            return newArray;
        }
        /// <summary>
        /// 使用AES加密 秘钥，需要128位
        /// </summary>
        public static string AesEncrypt(string content, string key = "", bool autoHandle = true)
        {
            try
            {
                if (key == "")
                    key = m_key;
                byte[] keyArray = Encoding.UTF8.GetBytes(key);
                if (autoHandle)
                {
                    keyArray = GetAesKey(keyArray, key);
                }
                byte[] toEncryptArray = Encoding.UTF8.GetBytes(content);

                SymmetricAlgorithm des = Aes.Create();
                des.Key = keyArray;
                des.Mode = CipherMode.ECB;
                des.Padding = PaddingMode.PKCS7;
                ICryptoTransform cTransform = des.CreateEncryptor();
                byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
                return Convert.ToBase64String(resultArray);
            }
            catch (Exception)
            {
                return null;
            }
        }
        /// <summary>
        /// 使用AES解密 秘钥，需要128位
        /// </summary>
        public static string AesDecrypt(string content, string key = "", bool autoHandle = true)
        {
            try
            {
                if (key == "")
                    key = m_key;
                byte[] keyArray = Encoding.UTF8.GetBytes(key);
                if (autoHandle)
                {
                    keyArray = GetAesKey(keyArray, key);
                }
                byte[] toEncryptArray = Convert.FromBase64String(content);

                SymmetricAlgorithm des = Aes.Create();
                des.Key = keyArray;
                des.Mode = CipherMode.ECB;
                des.Padding = PaddingMode.PKCS7;

                ICryptoTransform cTransform = des.CreateDecryptor();
                byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

                return Encoding.UTF8.GetString(resultArray);
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
    #endregion
}
