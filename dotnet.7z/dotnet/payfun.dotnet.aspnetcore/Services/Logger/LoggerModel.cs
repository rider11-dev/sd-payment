﻿using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet.asp.netcore
{
    public class LoggerModel
    {
        public string Application { get; set; }
        public string Message { get; set; }
        public string StackTrace { get; set; }

        /// <summary>
        /// 1 log
        /// 2 error
        /// </summary>
        public int Level { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}
