﻿

namespace payfun.dotnet.asp.netcore
{
    using Microsoft.Extensions.Options;
    using System;

    public class AggregateLogger : IAggregateLogger
    {
        private AppInfoOption appInfoOption;
        public AggregateLogger(IOptions<AppInfoOption> appInfoOption)
        {
            this.appInfoOption = appInfoOption.Value ?? throw new ArgumentException("请注入App信息");
        }

        public void LogError(string message, string stackTrace = null)
        {
            this.Write(message, 2, stackTrace);
        }

        public void LogInformation(string message, string stackTrace = null)
        {
            this.Write(message, 1, stackTrace);
        }

        public void Write(string application, string message, int level = 1, string stackTrace = null)
        {
            var log = new LoggerModel
            {
                Application = application,
                Message = message,
                StackTrace = stackTrace,
                Level = level
            };
            Console.WriteLine(log.ToJson());
        }

        public void Write(string message, int level = 1, string stackTrace = null)
        {
            var log = new LoggerModel
            {
                Application = appInfoOption.Application,
                Message = message,
                StackTrace = stackTrace,
                Level = level
            };
            Console.WriteLine(log.ToJson());
        }
    }
}
