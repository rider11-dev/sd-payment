﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace payfun.dotnet.asp.netcore
{
    public class LanguagePack
    {
        public static LanguagePack Instance;

        private Dictionary<string, string> langs;
        /// <summary>
        /// LangPack.xml绝对路径
        /// </summary>
        /// <param name="langPackPath"></param>
        public LanguagePack(string location, string langPackPath)
        {
            var x = XElement.Load(langPackPath);
            var items = x.Elements("lang").FirstOrDefault(p => p.Attribute("value").Value == location).Elements();

            this.langs = new Dictionary<string, string>();
            foreach (var item in items)
            {
                var key = item.Attribute("key").Value;
                var value = item.Attribute("value").Value;
                if (this.langs.ContainsKey(key))
                    throw new Exception($"重复的语言包Key：{key}");

                this.langs.Add(key, value);
            }

            Instance = this;
        }
        public string? this[string key]
        {
            get
            {
                if (this.langs.ContainsKey(key))
                    return this.langs[key];

                return key;
            }
        }
    }
}
