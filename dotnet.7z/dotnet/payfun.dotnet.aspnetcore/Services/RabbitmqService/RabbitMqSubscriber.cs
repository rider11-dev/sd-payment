﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using payfun.dotnet.asp.netcore;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace payfun.dotnet.netcore
{
    public class RabbitMqSubscriber : RabbitMqBase, IMessageSubscriber
    {
        private Type messageType { get; set; }
        private Func<object, Task<bool>> messageHandler { get; set; }

        public RabbitMqSubscriber(
            IAggregateLogger logger
             , IOptions<RabbitmqSubscriberOption> option)
             : base(logger, option)
        {
        }

        private void Consumer_Received(object sender, BasicDeliverEventArgs e)
        {
            if (TryGetMessage(e, messageType, out object message))
            {
                bool result = messageHandler(message).Result;

                if (result)
                {
                    channel.BasicAck(e.DeliveryTag, multiple: false);
                }
                else
                {
                    channel.BasicReject(e.DeliveryTag, requeue: true);
                    logger.LogError("ack failed");
                }
            }
            else
            {
                channel.BasicAck(e.DeliveryTag, multiple: false);
            }
        }
        private void StartConsumer()
        {
            StartChannel();

            EventingBasicConsumer consumer = new EventingBasicConsumer(channel);
            consumer.Received += Consumer_Received;
            int prefetchCount = (option as RabbitmqSubscriberOption).PrefetchCount;
            if (prefetchCount > 0)
            {
                channel.BasicQos(prefetchSize: 0, prefetchCount: (ushort)prefetchCount, global: false);
            }
            channel.BasicConsume(
                queue: (option as RabbitmqSubscriberOption).QueueName,
                autoAck: false,
                consumerTag: "",
                noLocal: true,
                exclusive: false,
                arguments: null,
                consumer: consumer
            );
            logger.LogInformation("rabbitmq consumer successfully");
        }

        public override void Start()
        {
            if (ConnectionOpened && ChannelOpened)
            {
                logger.LogInformation("rabbitmq connection and channel is opened");

                return;
            }

            StartConsumer();

            logger.LogInformation("rabbitmq start successfully");
        }

        private void Subscribe<TMessage>(Func<TMessage, Task<bool>> handler)
        {
            messageType = typeof(TMessage);
            messageHandler = (message) =>
            {
                try
                {
                    return handler((TMessage)message);
                }
                catch (Exception ex)
                {
                    return Task.FromResult(false);
                }
            };
            logger.LogInformation("rabbitmq subscribe completed");
        }
        public Task SubscribeAsync<TMessage>(string topic, Func<TMessage, Task<bool>> handler)
        {
            return Task.Run(() => Subscribe<TMessage>(handler));
        }

        private bool TryGetMessage(BasicDeliverEventArgs e, Type type, out object message)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>
            {
                { "exchange", e.Exchange },
                { "topic", e.RoutingKey }
            };

            try
            {
                string text = Encoding.UTF8.GetString(e.Body.ToArray());
                dictionary.Add("text", text);
                message = JsonConvert.DeserializeObject(text, type);
                return true;
            }
            catch (Exception ex)
            {
                dictionary.Add("reason", "rabbitmq receive message error");

                logger.LogError(ex.Message);

                message = default(object);
                return false;
            }
        }
    }
}
