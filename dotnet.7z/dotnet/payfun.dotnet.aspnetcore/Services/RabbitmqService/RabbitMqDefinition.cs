﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using payfun.dotnet.asp.netcore;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace payfun.dotnet.netcore
{
    public class RabbitMqDefinition : RabbitMqBase, IMessageDefinition
    {
        public RabbitMqDefinition(
              IAggregateLogger logger,
            IOptions<RabbitMQOption> option)
            : base(logger, option)
        {

        }
        public override void Start()
        {
            if (ConnectionOpened && ChannelOpened)
            {
                logger.LogInformation("rabbitmq connection and channel is opened");

                return;
            }
            StartChannel();
            logger.LogInformation("rabbitmq start successfully");
        }

        public void ExchangeDeclare(string exchange, string type, bool durable, bool autoDelete, IDictionary<string, object> arguments)
        {
            channel.ExchangeDeclare(exchange: exchange, type: type, durable: durable, autoDelete: autoDelete, arguments: arguments);
        }

        public void QueueBind(string queue, string exchange, string routingKey, IDictionary<string, object> arguments)
        {
            channel.QueueBind(queue: queue, exchange: exchange, routingKey: routingKey, arguments: arguments);
        }

        public QueueDeclareOk QueueDeclare(string queue, bool durable, bool exclusive, bool autoDelete, IDictionary<string, object> arguments)
        {
            return channel.QueueDeclare(queue: queue, durable: durable, exclusive: exclusive, autoDelete: autoDelete, arguments: arguments);
        }
    }
}
