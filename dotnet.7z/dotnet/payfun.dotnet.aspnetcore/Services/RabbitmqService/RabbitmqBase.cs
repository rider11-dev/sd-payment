﻿

namespace payfun.dotnet.netcore
{
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using payfun.dotnet.asp.netcore;
    using RabbitMQ.Client;
    using RabbitMQ.Client.Events;
    using RabbitMQ.Client.Exceptions;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    public abstract class RabbitMqBase : IDisposable
    {
        protected readonly IAggregateLogger logger;
        protected readonly RabbitMQOption option;
        public RabbitMqBase(IAggregateLogger logger
            , IOptions<RabbitMQOption> option)
        {
            this.logger = logger ?? throw new ArgumentException("IAggregateLogger");
            this.option = option.Value;
            Start();
        }
        protected IConnection connection = null;
        protected IModel channel = null;
        protected IBasicProperties properties = null;

        public bool ConnectionOpened => (connection != null) && connection.IsOpen;
        public bool ChannelOpened => (channel != null) && channel.IsOpen;

        protected void StartConnection()
        {
            if (ConnectionOpened)
            {
                connection.Close();
            }

            ConnectionFactory factory = new ConnectionFactory()
            {
                HostName = option.HostName,
                Port = option.Port,
                UserName = option.UserName,
                Password = option.Password,
                VirtualHost = option.VirtualHost,
                AutomaticRecoveryEnabled = true
            };
            try
            {
                logger.LogInformation("rabbitmq connection starting");
                connection = factory.CreateConnection();
                logger.LogInformation("rabbitmq connection successfully");
            }
            catch (BrokerUnreachableException)
            {
                logger.LogError("rabbitmq connection failed");
            }
        }
        protected void StartChannel()
        {
            if (ChannelOpened)
            {
                channel.Close();
            }

            StartConnection();

            channel = connection.CreateModel();

            properties = channel.CreateBasicProperties();
            properties.Persistent = true;

            logger.LogInformation("rabbitmq channel created successfully");
        }

        public abstract void Start();

        public void Dispose()
        {
            if (ChannelOpened)
            {
                channel.Close();
            }

            if (ConnectionOpened)
            {
                connection.Close();
            }
        }
    }
}
