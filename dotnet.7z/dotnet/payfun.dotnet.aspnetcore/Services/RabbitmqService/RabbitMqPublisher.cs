﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using payfun.dotnet.asp.netcore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace payfun.dotnet.netcore
{
    public class RabbitMqPublisher : RabbitMqBase, IMessagePublisher
    {
        public RabbitMqPublisher(
              IAggregateLogger logger
            , IOptions<RabbitmqPublisherOption> option)
            : base(logger, option)
        {
        }

        public override void Start()
        {
            if (ConnectionOpened && ChannelOpened)
            {
                logger.Write("rabbitmq connection and channel is opened");

                return;
            }
            StartChannel();
            logger.LogInformation("rabbitmq start successfully");
        }

        private bool Publish(string exchange, string topic, string message, IDictionary<string, object> dictionary)
        {
            try
            {
                innerPublish(exchange, topic, message, dictionary);
                return true;
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message);
                return false;
            }
        }

        private void innerPublish(string exchange, string topic, string message, IDictionary<string, object> headers)
        {
            properties.Headers = headers;
            channel.BasicPublish(
                exchange: exchange,
                routingKey: topic,
                body: Encoding.UTF8.GetBytes(message),
                basicProperties: properties,
                mandatory: true
            );
        }

        public Task<bool> PublishAsync<TMessage>(string topic, TMessage message)
        {
            string text = JsonConvert.SerializeObject(message, NewtonsoftJsonExtensions.DefaultSettings);
            return Task.Run(() => Publish(
                     exchange: option.ExchangeName,
                     topic: topic,
                     message: text,
                     dictionary: new Dictionary<string, Object>()));
        }

        public Task<bool> PublishAsync<TMessage>(string topic, TMessage message, IDictionary<string, object> valuePairs)
        {
            string text = JsonConvert.SerializeObject(message, NewtonsoftJsonExtensions.DefaultSettings);
            return Task.Run(() => Publish(
                      exchange: option.ExchangeName,
                      topic: topic,
                      message: text,
                      dictionary: valuePairs));
        }
    }
}
