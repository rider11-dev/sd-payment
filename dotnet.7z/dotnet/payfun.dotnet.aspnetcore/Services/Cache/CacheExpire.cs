﻿using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet.netcore
{
    public static class CacheExpire
    {
        public static int ExpireSeconds { get; } = 3600;
    }
}
