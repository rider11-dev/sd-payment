﻿using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace payfun.dotnet.netcore.Services
{
    /// <summary>
    /// 消息服务
    /// </summary>
    public interface IMessageService
    {
        /// <summary>
        /// 发送短信验证码
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [Post("/message/Sms")]
        public Task<ApiResponse<HttpResult>> SendSmsCode([Body(BodySerializationMethod.Serialized)] SmsCodeInput input);

        /// <summary>
        /// 发送钉钉消息
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [Post("/message/DingDing")]
        public Task<ApiResponse<HttpResult>> SendDingding([Body(BodySerializationMethod.Serialized)] SendDingReq input);

        #region 实体类
        public class SmsCodeInput
        {
            public string Channel { get; set; }

            public string Subject { get; set; }

            public string Phone { get; set; }

        }

        /// <summary>
        /// 发送钉钉请求参数
        /// </summary>
        public class SendDingReq
        {
            /// <summary>
            /// 钉钉Req
            /// </summary>
            public DingModel DingReq { get; set; }
            /// <summary>
            /// webhook
            /// </summary>
            public string Webhook { get; private set; } = "https://oapi.dingtalk.com/robot/send?access_token=76fd7d5934f59a1c054e259d39d1371d64f35911e0da3712e0c5b4bb5a6acb83";
            /// <summary>
            /// 密钥
            /// </summary>
            public string Secret { get; private set; } = "SEC70bfa7095bb2b1e1873db47bf728d083cde6c07126ae980f93ab779dec7b7eff";
        }

        /// <summary>
        /// 钉钉Req
        /// </summary>
        public class DingModel
        {
            /// <summary>
            ///消息类型
            /// </summary>
            public string Msgtype { get; set; } = "markdown";
            /// <summary>
            /// markdown内容
            /// </summary>
            public MarkDown Markdown { get; set; }
            /// <summary>
            /// @的人
            /// </summary>
            public At At { get; set; }
        }
        /// <summary>
        /// 
        /// </summary>
        public class MarkDown
        {
            /// <summary>
            /// 标题
            /// </summary>
            public string Title { get; set; }
            /// <summary>
            /// 内容
            /// </summary>
            public string Text { get; set; }
        }
        /// <summary>
        /// 
        /// </summary>
        public class At
        {
            /// <summary>
            /// 需要@的手机号
            /// </summary>
            public List<string> AtMobiles { get; set; }
            /// <summary>
            /// 是否@所有人
            /// </summary>
            public bool IsAtAll { get; set; }
        }
        /// <summary>
        /// 钉钉请求返回
        /// </summary>
        public class DingRsp
        {
            /// <summary>
            /// 错误信息
            /// </summary>
            public string Errmsg { get; set; }
            /// <summary>
            /// 错误码
            /// </summary>
            public int Errcode { get; set; }
        }
        #endregion
    }
}
