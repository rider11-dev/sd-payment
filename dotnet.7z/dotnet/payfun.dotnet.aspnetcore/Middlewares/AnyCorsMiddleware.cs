﻿using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace payfun.dotnet.asp.netcore
{
    /// <summary>
    /// 响应跨域
    /// </summary>
    public class AnyCorsMiddleware
    {
        private readonly RequestDelegate _next;
        public AnyCorsMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            if (!context.Response.Headers.ContainsKey("Access-Control-Allow-Origin"))
            {
                context.Response.Headers.Add("Access-Control-Allow-Origin", "*");
            }
            if (!context.Response.Headers.ContainsKey("Access-Control-Allow-Methods"))
            {
                context.Response.Headers.Add("Access-Control-Allow-Methods", "*");
            }

            if (!context.Response.Headers.ContainsKey("Access-Control-Allow-Headers"))
            {
                context.Response.Headers.Add("Access-Control-Allow-Headers", "authorization,content-type");
            }
            if (context.Request.Method == "OPTIONS")
            {
                context.Response.StatusCode = 200;
                return;
            }
            await _next(context);
        }
    }
}
