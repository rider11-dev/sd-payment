﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using Polly;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;
using System.Linq;
using System.Threading;
using Polly.Retry;
using System.IO;

namespace payfun.dotnet.asp.netcore
{
    /// <summary>
    /// httpclient扩展
    /// </summary>
    public static class HttpClientExtentions
    {
        /// <summary>
        /// 默认重试次数
        /// </summary>
        public const int DefaultRetries = 3;
        /// <summary>
        /// 可重试的http状态码
        /// </summary>
        public static int[] HttpStatusCodesWorthRetrying = new int[]
        {
               (int)HttpStatusCode.RequestTimeout, // 408
               (int)HttpStatusCode.InternalServerError, // 500
               (int)HttpStatusCode.BadGateway, // 502
               (int)HttpStatusCode.ServiceUnavailable, // 503
               (int)HttpStatusCode.GatewayTimeout // 504
        };
        /// <summary>
        /// 启用重试
        /// </summary>
        /// <param name="builder"></param>
        /// <param name="sleepDurations">集合个数就是重试次数；传空重试3次，间隔：1s,2s,4s</param>
        /// <returns></returns>
        public static IHttpClientBuilder UseWaitAndRetry(this IHttpClientBuilder builder, IEnumerable<TimeSpan> sleepDurations = null)
        {
            if (sleepDurations == null)
            {
                sleepDurations = GetDefaultSleepDurations();
            }
            return builder.AddTransientHttpErrorPolicy(builder =>
            {
                return builder.WaitAndRetryAsync(sleepDurations: sleepDurations, onRetry: (result, sleep, retryAttempt, context) => OnRetry(result, sleep, retryAttempt, context, HttpResponseMessageStatusCodeResolver));
            });
        }
        /// <summary>
        /// 启用重试
        /// </summary>
        /// <param name="builder"></param>
        /// <param name="retries">重试次数</param>
        /// <param name="sleepDurationProvider">等待时间，传空则默认等待3s</param>
        /// <returns></returns>
        public static IHttpClientBuilder UseWaitAndRetry(this IHttpClientBuilder builder, int retries, Func<int, TimeSpan> sleepDurationProvider = null)
        {
            if (sleepDurationProvider == null)
            {
                sleepDurationProvider = GetRetrySleep;
            }
            return builder.AddTransientHttpErrorPolicy(builder =>
            {
                return builder.WaitAndRetryAsync(retryCount: retries, sleepDurationProvider: sleepDurationProvider, onRetry: (result, sleep, retryAttempt, context) => OnRetry(result, sleep, retryAttempt, context, HttpResponseMessageStatusCodeResolver));
            });
        }

        /// <summary>
        /// 发送请求，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestBuilder"></param>
        /// <param name="sleepDurations">集合个数就是重试次数；传空重试3次，间隔：1s,2s,4s</param>
        /// <returns></returns>
        public static Task<HttpResponseMessage> SendWithRetryAsync(this HttpClient httpClient, Func<HttpRequestMessage> requestBuilder, IEnumerable<TimeSpan> sleepDurations = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            //var dd = Policy.HandleResult<HttpResponseMessage>(WorthRetry).CircuitBreakerAsync(1, TimeSpan.FromSeconds(5));
            //Policy.WrapAsync(dd).ExecuteAsync();

            return HttpWaitAndRetryAsync<HttpResponseMessage>(HttpResponseMessageStatusCodeResolver, sleepDurations)
                        .ExecuteAsync((cancel) =>
                        {
                            var reqMessage = requestBuilder();
                            return httpClient.SendAsync(reqMessage, cancel);
                        }, cancellationToken);
        }
        /// <summary>
        /// 发送请求，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestBuilder"></param>
        /// <param name="retries">重试次数</param>
        /// <param name="sleepDurationProvider">重试间隔</param>
        /// <returns></returns>
        public static Task<HttpResponseMessage> SendWithRetryAsync(this HttpClient httpClient, Func<HttpRequestMessage> requestBuilder, int retries, Func<int, TimeSpan> sleepDurationProvider = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            return HttpWaitAndRetryAsync<HttpResponseMessage>(HttpResponseMessageStatusCodeResolver, retries, sleepDurationProvider)
                    .ExecuteAsync((cancel) =>
                    {
                        var reqMessage = requestBuilder();
                        return httpClient.SendAsync(reqMessage, cancel);
                    }, cancellationToken);
        }

        /// <summary>
        /// 发送get请求，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestUri"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static Task<HttpResponseMessage> GetWithRetryAsync(this HttpClient httpClient, string requestUri, IEnumerable<TimeSpan> sleepDurations = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            return HttpWaitAndRetryAsync<HttpResponseMessage>(HttpResponseMessageStatusCodeResolver, sleepDurations)
                        .ExecuteAsync((cancel) => httpClient.GetAsync(requestUri, cancel), cancellationToken);
        }
        /// <summary>
        /// 发送get请求，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestUri"></param>
        /// <param name="retries"></param>
        /// <param name="sleepDurationProvider"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static Task<HttpResponseMessage> GetWithRetryAsync(this HttpClient httpClient, string requestUri, int retries, Func<int, TimeSpan> sleepDurationProvider = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            return HttpWaitAndRetryAsync<HttpResponseMessage>(HttpResponseMessageStatusCodeResolver, retries, sleepDurationProvider)
                    .ExecuteAsync((cancel) => httpClient.GetAsync(requestUri, cancel), cancellationToken);
        }
        /// <summary>
        /// 发送get请求获取字符串内容，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestUri"></param>
        /// <param name="sleepDurations"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static async Task<string> GetStringWithRetryAsync(this HttpClient httpClient, string requestUri, IEnumerable<TimeSpan> sleepDurations = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            var rsp = await GetWithRetryAsync(httpClient, requestUri, sleepDurations, cancellationToken);
            return await rsp.Content.ReadAsStringAsync();
        }
        /// <summary>
        /// 发送get请求获取字符串内容，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestUri"></param>
        /// <param name="retries"></param>
        /// <param name="sleepDurationProvider"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static async Task<string> GetStringWithRetryAsync(this HttpClient httpClient, string requestUri, int retries, Func<int, TimeSpan> sleepDurationProvider = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            var rsp = await GetWithRetryAsync(httpClient, requestUri, retries, sleepDurationProvider, cancellationToken);
            return await rsp.Content.ReadAsStringAsync();
        }
        /// <summary>
        /// 发送get请求获取二进制数组，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestUri"></param>
        /// <param name="sleepDurations"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static async Task<byte[]> GetBytesWithRetryAsync(this HttpClient httpClient, string requestUri, IEnumerable<TimeSpan> sleepDurations = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            var rsp = await GetWithRetryAsync(httpClient, requestUri, sleepDurations, cancellationToken);
            return await rsp.Content.ReadAsByteArrayAsync();
        }
        /// <summary>
        /// 发送get请求获取二进制数组，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestUri"></param>
        /// <param name="retries"></param>
        /// <param name="sleepDurationProvider"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static async Task<byte[]> GetBytesWithRetryAsync(this HttpClient httpClient, string requestUri, int retries, Func<int, TimeSpan> sleepDurationProvider = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            var rsp = await GetWithRetryAsync(httpClient, requestUri, retries, sleepDurationProvider, cancellationToken);
            return await rsp.Content.ReadAsByteArrayAsync();
        }
        /// <summary>
        /// 发送get请求获取响应流，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestUri"></param>
        /// <param name="sleepDurations"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static async Task<Stream> GetStreamWithRetryAsync(this HttpClient httpClient, string requestUri, IEnumerable<TimeSpan> sleepDurations = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            var rsp = await GetWithRetryAsync(httpClient, requestUri, sleepDurations, cancellationToken);
            return await rsp.Content.ReadAsStreamAsync();
        }
        /// <summary>
        /// 发送get请求获取响应流，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestUri"></param>
        /// <param name="retries"></param>
        /// <param name="sleepDurationProvider"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static async Task<Stream> GetStreamWithRetryAsync(this HttpClient httpClient, string requestUri, int retries, Func<int, TimeSpan> sleepDurationProvider = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            var rsp = await GetWithRetryAsync(httpClient, requestUri, retries, sleepDurationProvider, cancellationToken);
            return await rsp.Content.ReadAsStreamAsync();
        }
        /// <summary>
        /// 发起post请求，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestUri"></param>
        /// <param name="content"></param>
        /// <param name="sleepDurations"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static Task<HttpResponseMessage> PostWithRetryAsync(this HttpClient httpClient, string requestUri, HttpContent content, IEnumerable<TimeSpan> sleepDurations = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            return HttpWaitAndRetryAsync<HttpResponseMessage>(HttpResponseMessageStatusCodeResolver, sleepDurations)
                    .ExecuteAsync((cancel) => httpClient.PostAsync(requestUri, content), cancellationToken);
        }
        /// <summary>
        /// 发起post请求，支持重试
        /// </summary>
        /// <param name="httpClient"></param>
        /// <param name="requestUri"></param>
        /// <param name="content"></param>
        /// <param name="retries"></param>
        /// <param name="sleepDurationProvider"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static Task<HttpResponseMessage> PostWithRetryAsync(this HttpClient httpClient, string requestUri, HttpContent content, int retries, Func<int, TimeSpan> sleepDurationProvider = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            return HttpWaitAndRetryAsync<HttpResponseMessage>(HttpResponseMessageStatusCodeResolver, retries, sleepDurationProvider)
                    .ExecuteAsync((cancel) => httpClient.PostAsync(requestUri, content), cancellationToken);
        }
        /// <summary>
        /// http调用，支持重试
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="httpStatusCodeResolver"></param>
        /// <param name="action"></param>
        /// <param name="sleepDurations"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static TResult RequestWithRetry<TResult>(Func<TResult, int> httpStatusCodeResolver, Func<CancellationToken, TResult> action, IEnumerable<TimeSpan> sleepDurations = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            return HttpWaitAndRetry(httpStatusCodeResolver, sleepDurations)
                    .Execute(action, cancellationToken);
        }
        /// <summary>
        /// http调用，支持重试
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="httpStatusCodeResolver"></param>
        /// <param name="action"></param>
        /// <param name="retries"></param>
        /// <param name="sleepDurationProvider"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static TResult RequestWithRetry<TResult>(Func<TResult, int> httpStatusCodeResolver, Func<CancellationToken, TResult> action, int retries, Func<int, TimeSpan> sleepDurationProvider = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            return HttpWaitAndRetry(httpStatusCodeResolver, retries, sleepDurationProvider)
                .Execute(action, cancellationToken);
        }

        /// <summary>
        /// http调用，支持重试
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="httpStatusCodeResolver"></param>
        /// <param name="action"></param>
        /// <param name="sleepDurations"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static Task<TResult> RequestWithRetryAsync<TResult>(Func<TResult, int> httpStatusCodeResolver, Func<CancellationToken, Task<TResult>> action, IEnumerable<TimeSpan> sleepDurations = null, CancellationToken cancellationToken = default(CancellationToken))
        {           
            return HttpWaitAndRetryAsync(httpStatusCodeResolver, sleepDurations)
                .ExecuteAsync(action, cancellationToken);
        }
        /// <summary>
        /// http调用，支持重试
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="httpStatusCodeResolver"></param>
        /// <param name="action"></param>
        /// <param name="retries"></param>
        /// <param name="sleepDurationProvider"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static Task<TResult> RequestWithRetryAsync<TResult>(Func<TResult, int> httpStatusCodeResolver, Func<CancellationToken, Task<TResult>> action, int retries, Func<int, TimeSpan> sleepDurationProvider = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            return HttpWaitAndRetryAsync(httpStatusCodeResolver, retries, sleepDurationProvider)
                .ExecuteAsync(action, cancellationToken);
        }
        private static RetryPolicy<TResult> HttpWaitAndRetry<TResult>(Func<TResult, int> httpStatusCodeResolver, IEnumerable<TimeSpan> sleepDurations = null)
        {
            if (sleepDurations == null)
            {
                sleepDurations = GetDefaultSleepDurations();
            }
            return HandleHttpResult(httpStatusCodeResolver)
                .WaitAndRetry(sleepDurations, (result, sleep, retryAttempt, context) => OnRetry(result, sleep, retryAttempt, context, httpStatusCodeResolver));
        }
        private static RetryPolicy<TResult> HttpWaitAndRetry<TResult>(Func<TResult, int> httpStatusCodeResolver, int retries, Func<int, TimeSpan> sleepDurationProvider = null)
        {
            if (sleepDurationProvider == null)
            {
                sleepDurationProvider = GetRetrySleep;
            }
            return HandleHttpResult(httpStatusCodeResolver).WaitAndRetry(retries, sleepDurationProvider, (result, sleep, retryAttempt, context) => OnRetry(result, sleep, retryAttempt, context, httpStatusCodeResolver));
        }
        private static AsyncRetryPolicy<TResult> HttpWaitAndRetryAsync<TResult>(Func<TResult, int> httpStatusCodeResolver, IEnumerable<TimeSpan> sleepDurations = null)
        {
            if (sleepDurations == null)
            {
                sleepDurations = GetDefaultSleepDurations();
            }
            return HandleHttpResult(httpStatusCodeResolver).WaitAndRetryAsync(sleepDurations, (result, sleep, retryAttempt, context) => OnRetry(result, sleep, retryAttempt, context, httpStatusCodeResolver));
        }
        private static AsyncRetryPolicy<TResult> HttpWaitAndRetryAsync<TResult>(Func<TResult, int> httpStatusCodeResolver, int retries, Func<int, TimeSpan> sleepDurationProvider = null)
        {
            if (sleepDurationProvider == null)
            {
                sleepDurationProvider = GetRetrySleep;
            }
            return HandleHttpResult(httpStatusCodeResolver).WaitAndRetryAsync(retries, sleepDurationProvider, (result, sleep, retryAttempt, context) => OnRetry(result, sleep, retryAttempt, context, httpStatusCodeResolver));
        }
        private static PolicyBuilder<TResult> HandleHttpResult<TResult>(Func<TResult, int> httpStatusCodeResolver)
        {
            return Policy.HandleResult<TResult>(result =>
            {
                var statusCode = httpStatusCodeResolver(result);
                return HttpStatusCodesWorthRetrying.Contains(statusCode);
            });
        }
        private static int HttpResponseMessageStatusCodeResolver(HttpResponseMessage rsp) => (int)rsp.StatusCode;
        private static TimeSpan GetRetrySleep(int retryAttempt) => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt - 1));
        private static IEnumerable<TimeSpan> GetDefaultSleepDurations()
        {
            var sleeps = new List<TimeSpan>();
            for (var idx = 1; idx <= DefaultRetries; idx++)
            {
                sleeps.Add(GetRetrySleep(idx));
            }
            return sleeps;
        }
        private static void OnRetry<TResult>(DelegateResult<TResult> result, TimeSpan sleep, int retryAttempt, Context context, Func<TResult, int> httpStatusCodeResolver)
        {
            Console.WriteLine($"请求重试:attempt={retryAttempt},code={httpStatusCodeResolver(result.Result)},sleep={sleep.TotalSeconds}s");
        }
    }
}
