﻿
namespace payfun.dotnet.asp.netcore
{
    using Microsoft.AspNetCore.Mvc;

    public static class ControllerBaseExtension
    {
        public static OkObjectResult BadHttpResult(this ControllerBase controller, string msg = "", object data = null)
        {
            return new OkObjectResult(new HttpResult
            {
                code = 400,
                message = msg,
                data = data
            });
        }
        public static OkObjectResult OkHttpResult(this ControllerBase controller, string msg = "", object data = null)
        {
            return new OkObjectResult(new HttpResult
            {
                code = 200,
                message = msg,
                data = data,
            });
        }
    }
}
