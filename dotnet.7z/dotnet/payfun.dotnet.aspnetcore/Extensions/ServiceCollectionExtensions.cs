﻿namespace payfun.dotnet.asp.netcore
{
    using CSRedis;
    using Dapr.Client;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Localization;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using payfun.dotnet.netcore.Options;
    using payfun.dotnet.netcore.Services;
    using Refit;
    using System;
    using System.Globalization;
    using System.Linq;
    using System.Text.Encodings.Web;
    using System.Text.Unicode;
    using zipkin4net;
    using zipkin4net.Middleware;
    using zipkin4net.Tracers.Zipkin;
    using zipkin4net.Transport.Http;

    public static class ServiceCollectionExtensions
    {

        public static IServiceCollection AddCentralRoutePrefix(this IServiceCollection services)
        {
            AppInfoOption appInfoOption = services
                .BuildServiceProvider()
                .GetRequiredService<IOptions<AppInfoOption>>().Value;
            services.AddControllers(opt =>
            {
                opt.UseCentralRoutePrefix(new Microsoft.AspNetCore.Mvc.RouteAttribute(appInfoOption.Prefix));
            });
            return services;
        }

        public static IServiceCollection AddHttp(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddCors(option =>
            {
                option.AddPolicy("any", builder =>
                {
                    builder.WithOrigins("http://*.*.*.*").AllowAnyMethod().AllowAnyHeader().AllowCredentials();
                });
            }).AddControllers(option =>
            {
                option.Filters.Add(typeof(ExceptionFilter));
                option.AllowEmptyInputInBodyModelBinding = true;

            }).AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.Encoder = JavaScriptEncoder.Create(UnicodeRanges.All);
                options.JsonSerializerOptions.PropertyNamingPolicy = null;
            }).AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                options.SerializerSettings.DateFormatString = "yyyy-MM-dd HH:mm";
                //options.SerializerSettings.Converters.Add(new JsonCustomDynamicCeilingWith2Convert());
                //options.SerializerSettings.Converters.Add(new JsonCustomDynamicFloorWith2Convert());
            });
            return services;
        }


        public static IServiceCollection AddRedis(this IServiceCollection services, IConfiguration configuration)
        {
            RedisOption redisOption = services
                        .BuildServiceProvider()
                        .GetRequiredService<IOptions<RedisOption>>().Value;
            if (redisOption == null)
            {
                throw new ArgumentException("请配置redisOption");
            }
            RedisHelper.Initialization(new CSRedisClient(redisOption.Connection));
            services.AddSingleton<ICache>(new RedisCache(RedisHelper.Instance));
            return services;
        }


        public static IServiceCollection AddLangPack(this IServiceCollection services, string xmlPath)
        {
            AppInfoOption appInfoOption = services
                     .BuildServiceProvider()
                     .GetRequiredService<IOptions<AppInfoOption>>().Value;
            services.AddSingleton(new LanguagePack(appInfoOption.Location, xmlPath));
            return services;
        }


        public static IServiceCollection AddLanguages(this IServiceCollection services,
                     IConfiguration configuration,
                     string ResourcesPath = "Resources")
        {
            services.Configure<LanguageOption>(configuration.GetSection("Languages"));
            var option = services
                .BuildServiceProvider()
                .GetRequiredService<IOptions<LanguageOption>>().Value;

            services.AddMemoryCache();
            services.AddPortableObjectLocalization(options => options.ResourcesPath = ResourcesPath);
            if (option == null || option.Supporteds.Count == 0)
            {
                throw new ArgumentException("请配置Languages");
            }
            var supportedCultures = option.Supporteds.Select(s => new CultureInfo(s)).ToArray();
            services.Configure<RequestLocalizationOptions>(options =>
            {
                options.DefaultRequestCulture = new RequestCulture(option.Default);
                // Formatting numbers, dates, etc.
                options.SupportedCultures = supportedCultures;
                options.SupportedUICultures = supportedCultures;
            });
            return services;
        }

        public static IApplicationBuilder UseLanguages(this IApplicationBuilder app)
        {
            var option = app.ApplicationServices
                   .GetRequiredService<IOptions<LanguageOption>>().Value;
            var languages = option.Supporteds.Select(s => s).ToArray();
            app.UseRequestLocalization(cultureOptions =>
            {
                cultureOptions.AddSupportedCultures(languages)
                .AddSupportedUICultures(languages);
            });
            return app;
        }

        public static IApplicationBuilder UseZipkinTrace(this IApplicationBuilder app, ILoggerFactory loggerFactory,
            IHostApplicationLifetime lifetime)
        {
            var option = (app.ApplicationServices.GetRequiredService<IOptions<ZipkinOption>>()).Value;
            if (string.IsNullOrEmpty(option.applicationName) || string.IsNullOrEmpty(option.zipkinCollectorUrl))
            {
                throw new ArgumentNullException("ZipkinOption");
            }
            lifetime.ApplicationStarted.Register(() =>
            {
                TraceManager.SamplingRate = 1.0f;//记录数据密度，1.0代表全部记录
                var logger = new TracingLogger(loggerFactory, "zipkin4net");

                var httpSender = new HttpZipkinSender(option.zipkinCollectorUrl, "application/json");
                var tracer = new ZipkinTracer(httpSender, new JSONSpanSerializer(), new Statistics());
                var consoleTracer = new zipkin4net.Tracers.ConsoleTracer();
                TraceManager.RegisterTracer(tracer);
                TraceManager.Start(logger);
            });
            lifetime.ApplicationStopped.Register(() => TraceManager.Stop());

            app.UseTracing(option.applicationName, null, p =>
            {
                if (p.HasValue)
                {
                    if (p.Value.EndsWith("healthchecks"))
                    {
                        return false;
                    }
                    else if (p.Value.EndsWith("metrics"))
                    {
                        return false;
                    }
                    else if (p.Value.EndsWith("health"))
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    return false;
                }
            });
            return app;
        }


        /// <summary>
        /// 注册类型化服务调用、dapr
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="services"></param>
        /// <param name="appId">dapr应用id</param>
        /// <param name="environment"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static IServiceCollection AddRefitClientWithDapr<T>(this IServiceCollection services, string appId, IHostEnvironment environment) where T : class
        {
            if (string.IsNullOrWhiteSpace(appId))
            {
                throw new ArgumentNullException(nameof(appId));
            }
            if (environment == null)
            {
                throw new ArgumentNullException(nameof(environment));
            }
            var settings = new RefitSettings(new NewtonsoftJsonContentSerializer());
            if (environment.IsDevelopmentOrDev())
            {
                services.AddRefitClient<T>(settings).ConfigureHttpClient(options => options.BaseAddress = new Uri("http://api.t.dev.pay.fun"));
            }
            else
            {
                services.AddRefitClient<T>(settings).ConfigureHttpClient(options => options.BaseAddress = new Uri($"http://{appId}")).AddHttpMessageHandler(_ => new InvocationHandler());
            }
            return services;
        }
        /// <summary>
        /// 注册消息发送服务调用
        /// </summary>
        /// <param name="services"></param>
        /// <param name="environment"></param>
        /// <param name="appId">dapr应用id</param>
        /// <returns></returns>
        public static IServiceCollection AddRefitMessageService(this IServiceCollection services, IHostEnvironment environment, string appId = "message-http") => AddRefitClientWithDapr<IMessageService>(services: services, appId: appId, environment: environment);
    }
}
