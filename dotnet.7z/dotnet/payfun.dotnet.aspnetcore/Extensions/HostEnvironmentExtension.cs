﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace payfun.dotnet.asp.netcore
{
    public static class HostEnvironmentExtension 
    {
        public static bool IsDevelopmentOrDev(this IHostEnvironment Environment)
        {
            return Environment.EnvironmentName.Equals("Development",StringComparison.InvariantCultureIgnoreCase) || Environment.EnvironmentName.Equals("dev", StringComparison.InvariantCultureIgnoreCase);
        }


        public static bool IsProductionOrPro(this IHostEnvironment Environment)
        {
            return Environment.EnvironmentName.Equals("Production", StringComparison.InvariantCultureIgnoreCase) || Environment.EnvironmentName.Equals("pro", StringComparison.InvariantCultureIgnoreCase);
        }


        public static bool IsFat(this IHostEnvironment Environment)
        {
            return Environment.EnvironmentName.Equals("fat", StringComparison.InvariantCultureIgnoreCase);
        }
    }
}
