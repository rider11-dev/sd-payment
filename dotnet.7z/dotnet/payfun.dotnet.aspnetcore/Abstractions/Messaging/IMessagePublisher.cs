﻿namespace payfun.dotnet.netcore
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    public interface IMessagePublisher : IDisposable
    {
        Task<bool> PublishAsync<TMessage>(string topic, TMessage message);

        Task<bool> PublishAsync<TMessage>(string topic, TMessage message, IDictionary<string, object> valuePairs);
    }
}
