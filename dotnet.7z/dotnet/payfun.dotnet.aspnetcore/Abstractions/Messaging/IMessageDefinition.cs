﻿namespace payfun.dotnet.netcore
{
    using RabbitMQ.Client;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    public interface IMessageDefinition : IDisposable
    {
        void ExchangeDeclare(string exchange, string type, bool durable, bool autoDelete, IDictionary<string, object> arguments);
        QueueDeclareOk QueueDeclare(string queue, bool durable, bool exclusive, bool autoDelete, IDictionary<string, object> arguments);
        void QueueBind(string queue, string exchange, string routingKey, IDictionary<string, object> arguments);
    }
}
