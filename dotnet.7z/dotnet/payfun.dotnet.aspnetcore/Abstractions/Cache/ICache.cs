﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace payfun.dotnet.asp.netcore
{
    public interface ICache
    {
        Task SetObjectAsync(string key, object value, int expireSeconds = -1);
        Task<T> GetObjectAsync<T>(string key);
        Task RemoveObjectsAsync(params string[] key);
    }
}
