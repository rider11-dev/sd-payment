﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace payfun.dotnet.asp.netcore
{
    public interface IAggregateLogger
    {
        void Write(string application, string message, int level = 1, string stackTrace = null);
        void Write(string message, int level = 1, string stackTrace = null);
        void LogInformation(string message,string stackTrace = null);
        void LogError(string message, string stackTrace = null);


    }
}
