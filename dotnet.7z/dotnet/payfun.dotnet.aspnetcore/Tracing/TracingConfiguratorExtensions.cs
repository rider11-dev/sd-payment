﻿using Microsoft.Extensions.DependencyInjection;
using SkyApm.Tracing;
using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet.asp.netcore
{
    public static class TracingConfiguratorExtensions
    {
        public static IServiceCollection AddTracing(this IServiceCollection services)
        {
            services.AddSingleton<ISamplingInterceptor, CustomSamplingInterceptor>();
            return services;
        }
    }
}
