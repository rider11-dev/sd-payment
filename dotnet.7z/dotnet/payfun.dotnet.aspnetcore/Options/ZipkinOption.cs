﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace payfun.dotnet.asp.netcore
{
    public class ZipkinOption
    {
        public string zipkinCollectorUrl { get; set; }
        public string applicationName { get; set; }
    }
}
