﻿using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet.asp.netcore
{
    public class RedisOption
    {
        public string Connection { get; set; }
    }
}
