﻿using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet.asp.netcore
{
    public class AppInfoOption
    {
        public string Location { get; set; }
        public string Prefix { get; set; }
        public string Application { get; set; }
        public string Name { get; set; }
    }
}
