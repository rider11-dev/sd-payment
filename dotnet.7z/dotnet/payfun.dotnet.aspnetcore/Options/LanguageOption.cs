﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace payfun.dotnet.netcore.Options
{
    public class LanguageOption
    {
        public List<string> Supporteds { get; set; } = new List<string>();
        public string Default { get; set; }
    }
}
