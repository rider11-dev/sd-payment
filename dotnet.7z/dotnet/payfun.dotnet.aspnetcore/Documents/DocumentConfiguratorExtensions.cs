﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using payfun.dotnet.netcore;
using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet.asp.netcore
{
    public static class DocumentConfiguratorExtensions
    {
        public static IServiceCollection AddDocument(this IServiceCollection services, string xmlPath,
            string version = "v1")
        {
            AppInfoOption appInfoOption = services
                .BuildServiceProvider()
                .GetRequiredService<IOptions<AppInfoOption>>().Value;
            services.AddSwaggerGen(c =>
            {

                c.IncludeXmlComments(xmlPath, true);
                c.IgnoreObsoleteProperties();

                //Bearer 的scheme定义
                var securityScheme = new OpenApiSecurityScheme()
                {
                    Description = "JWT Authorization header using the Bearer scheme. Example: \"Bearer {token}\"",
                    Name = "Authorization",
                    //参数添加在头部
                    In = ParameterLocation.Header,
                    //使用Authorize头部
                    Type = SecuritySchemeType.Http,
                    //内容为以 bearer开头
                    Scheme = "bearer",
                    BearerFormat = "JWT"
                };

                //把所有方法配置为增加bearer头部信息
                var securityRequirement = new OpenApiSecurityRequirement
                    {
                        {
                                new OpenApiSecurityScheme
                                {
                                    Reference = new OpenApiReference
                                    {
                                        Type = ReferenceType.SecurityScheme,
                                        Id = "bearerAuth"
                                    }
                                },
                                new string[] {}
                        }
                    };

                //注册到swagger中
                c.AddSecurityDefinition("bearerAuth", securityScheme);
                c.AddSecurityRequirement(securityRequirement);


                c.SwaggerDoc("v1", new OpenApiInfo { Title = appInfoOption.Name, Version = "v1" });
                c.IncludeXmlComments(xmlPath);
                c.IgnoreObsoleteProperties();
                c.ParameterFilter<SwaggerEnumParamFilter>();
                c.DocumentFilter<SwaggerEnumFilter>(appInfoOption.Application);
            });

            return services;
        }
    }
}
