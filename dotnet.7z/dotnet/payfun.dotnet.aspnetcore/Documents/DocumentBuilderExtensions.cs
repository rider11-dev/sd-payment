﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet.asp.netcore
{
    public static class DocumentBuilderExtensions
    {
        public static IApplicationBuilder UseDocument(this IApplicationBuilder app,
            IWebHostEnvironment env,
            AppInfoOption appInfoOption)
        {
            if (env.IsDevelopmentOrDev() || env.IsFat())
            {
                app.UseSwagger(c =>
                {
                    c.PreSerializeFilters.Add((swagger, httpReq) => swagger.Servers = null);
                    c.RouteTemplate = appInfoOption.Prefix + "/swagger/{documentName}/swagger.json";
                });
                //启用中间件服务对swagger-ui，指定Swagger JSON终结点
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint($"/{appInfoOption.Prefix}/swagger/v1/swagger.json", "HTTP API V1");
                    c.RoutePrefix = $"{appInfoOption.Prefix}/swagger";
                });
            }
            return app;
        }
    }
}
