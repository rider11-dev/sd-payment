﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace payfun.dotnet.http
{
    public class InnerHttpClient : IHttpClient
    {
        private IHttpClientFactory Factory;

        public InnerHttpClient(IHttpClientFactory httpClientFactory)
        {
            this.Factory = httpClientFactory;
        }
        public async Task<HttpResponseResult<byte[]>> GetByteArrayAsync(string requestUri, string bearer = null, Dictionary<string, string> headers = null)
        {
            var request = this.CreateRequest(requestUri, HttpMethod.Get, bearer, headers);
            var response = await this.SendAsync(request).ConfigureAwait(false);
            var value = await response.Content.ReadAsByteArrayAsync();
            var httpResult = new HttpResponseResult<byte[]>(response.StatusCode, response.IsSuccessStatusCode, value);
            return httpResult;
        }

        public async Task<HttpResponseResult<Stream>> GetStreamAsync(string requestUri, string bearer = null, Dictionary<string, string> headers = null)
        {
            var request = this.CreateRequest(requestUri, HttpMethod.Get, bearer, headers);
            var response = await this.SendAsync(request).ConfigureAwait(false);
            var value = await response.Content.ReadAsStreamAsync();
            var httpResult = new HttpResponseResult<Stream>(response.StatusCode, response.IsSuccessStatusCode, value);
            return httpResult;
        }

        public async Task<HttpResponseResult<string>> GetStringAsync(string requestUri, string bearer = null, Dictionary<string, string> headers = null)
        {
            var request = this.CreateRequest(requestUri, HttpMethod.Get, bearer, headers);
            var response = await this.SendAsync(request).ConfigureAwait(false);
            var value = await response.Content.ReadAsStringAsync();
            var httpResult = new HttpResponseResult<string>(response.StatusCode, response.IsSuccessStatusCode, value);
            return httpResult;
        }

        public async Task<HttpResponseResult<string>> DeleteAsync(string requestUri, string bearer = null, Dictionary<string, string> headers = null)
        {
            var request = this.CreateRequest(requestUri, HttpMethod.Delete, bearer, headers);
            var response = await this.SendAsync(request).ConfigureAwait(false);
            var value = await response.Content.ReadAsStringAsync();
            var httpResult = new HttpResponseResult<string>(response.StatusCode, response.IsSuccessStatusCode, value);
            return httpResult;
        }

        public async Task<HttpResponseResult<string>> PostAsync(string requestUri, HttpContent content, string bearer = null)
        {
            var request = this.CreateRequests(requestUri, HttpMethod.Post, bearer);
            request.Content = content;
            var response = await this.SendAsync(request).ConfigureAwait(false);
            var value = await response.Content.ReadAsStringAsync();
            var httpResult = new HttpResponseResult<string>(response.StatusCode, response.IsSuccessStatusCode, value);
            return httpResult;
        }

        public async Task<HttpResponseResult<string>> PutAsync(string requestUri, HttpContent content, string bearer = null)
        {
            var request = this.CreateRequest(requestUri, HttpMethod.Put, bearer);
            request.Content = content;
            var response = await this.SendAsync(request).ConfigureAwait(false);
            var value = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var httpResult = new HttpResponseResult<string>(response.StatusCode, response.IsSuccessStatusCode, value);
            return httpResult;
        }

        public async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request)
        {
            var client = this.Factory.GetHttpClient();
            var response = await client.SendAsync(request).ConfigureAwait(false);
            return response;

        }
        private HttpRequestMessage CreateRequests(string requestUri, HttpMethod method, string bearer, Dictionary<string, string> headers = null)
        {
            var request = new HttpRequestMessage();
            request.Headers.Accept.Clear();
            if (!string.IsNullOrEmpty(bearer))
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);
            request.Method = method;
            request.RequestUri = new Uri(requestUri);
            if (headers != null)
            {
                foreach (var item in headers)
                {
                    request.Headers.Add(item.Key, item.Value);
                }
            }
            return request;
        }
        private HttpRequestMessage CreateRequest(string requestUri, HttpMethod method, string bearer, Dictionary<string, string> headers = null)
        {
            var request = new HttpRequestMessage();
            request.Method = method;
            request.RequestUri = new Uri(requestUri);

            if (!string.IsNullOrEmpty(bearer))
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearer);

            if (headers != null)
            {
                foreach (var item in headers)
                {
                    request.Headers.Add(item.Key, item.Value);
                }
            }
            return request;
        }
    }
}
