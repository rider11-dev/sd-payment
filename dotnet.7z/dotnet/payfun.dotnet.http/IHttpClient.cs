﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace payfun.dotnet.http
{

    public interface IHttpClient
    {
        Task<HttpResponseResult<byte[]>> GetByteArrayAsync(string requestUri, string bearer = null, Dictionary<string, string> headers = null);

        Task<HttpResponseResult<Stream>> GetStreamAsync(string requestUri, string bearer = null, Dictionary<string, string> headers = null);

        Task<HttpResponseResult<string>> GetStringAsync(string requestUri, string bearer = null, Dictionary<string, string> headers = null);

        Task<HttpResponseResult<string>> DeleteAsync(string requestUri, string bearer = null, Dictionary<string, string> headers = null);

        Task<HttpResponseResult<string>> PostAsync(string requestUri, HttpContent content, string bearer = null);

        Task<HttpResponseResult<string>> PutAsync(string requestUri, HttpContent content, string bearer = null);

        Task<HttpResponseMessage> SendAsync(HttpRequestMessage request);
    }


}
