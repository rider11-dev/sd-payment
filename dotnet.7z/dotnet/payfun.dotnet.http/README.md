How To Use?


public void ConfigureServices(IServiceCollection services)
{
    
    services.AddSingleton(typeof(IHttpClient), typeof(InnerHttpClient));
}

