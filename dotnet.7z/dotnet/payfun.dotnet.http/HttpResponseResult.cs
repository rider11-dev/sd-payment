﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace payfun.dotnet.http
{
    public class HttpResponseResult<T>
    {
        public HttpResponseResult()
        {

        }
        public HttpResponseResult(HttpStatusCode code, bool isSuccessStatusCode, T t)
        {
            this.StatusCode = code;
            this.ResponseContent = t;
            this.IsSuccessStatusCode = isSuccessStatusCode;
        }
        public HttpStatusCode StatusCode { get; private set; }

        public bool IsSuccessStatusCode { get; private set; }
        public T ResponseContent { get; private set; }
    }
}
