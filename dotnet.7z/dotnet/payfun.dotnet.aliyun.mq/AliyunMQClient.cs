﻿using System;
using System.Collections.Concurrent;
using payfun.dotnet.aliyun.mq.Model.Exp;
using payfun.dotnet.aliyun.mq.Runtime;
using payfun.dotnet.aliyun.mq.Runtime.Internal.Auth;

namespace payfun.dotnet.aliyun.mq
{
    public partial class AliyunMQClient : AliyunServiceClient
    {
        #region Constructors
        public AliyunMQClient(AliyunMQClienOption option)
    : base(option.AccessKeyId, option.SecretAccessKey, new MQConfig { RegionEndpoint = new Uri(option.Endpoint) }, null)
        {
            this.Producers = new ConcurrentDictionary<string, MQProducer>();
            this.Consumers = new ConcurrentDictionary<string, MQConsumer>();
        }

        public AliyunMQClient(string accessKeyId, string secretAccessKey, string regionEndpoint)
            : base(accessKeyId, secretAccessKey, new MQConfig { RegionEndpoint = new Uri(regionEndpoint) }, null)
        {
            this.Producers = new ConcurrentDictionary<string, MQProducer>();
            this.Consumers = new ConcurrentDictionary<string, MQConsumer>();
        }

        public AliyunMQClient(string accessKeyId, string secretAccessKey, string regionEndpoint, string stsToken)
            : base(accessKeyId, secretAccessKey, new MQConfig { RegionEndpoint = new Uri(regionEndpoint) }, stsToken)
        {
            this.Producers = new ConcurrentDictionary<string, MQProducer>();
            this.Consumers = new ConcurrentDictionary<string, MQConsumer>();
        }

        #endregion

        #region Overrides

        protected override IServiceSigner CreateSigner()
        {
            return new MQSigner();
        }

        #endregion

        #region Dispose

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }

        #endregion

        private ConcurrentDictionary<string, MQProducer> Producers;
        public MQProducer GetProducer(string instanceId, string topicName)
        {
            if (string.IsNullOrEmpty(topicName))
            {
                throw new MQException("TopicName is null or empty");
            }

            var key = $"{instanceId}_{topicName}";
            if (this.Producers.ContainsKey(key))
                return this.Producers[key];

            var producer = new MQProducer(instanceId, topicName, this);
            this.Producers.TryAdd(key, producer);

            return producer;
        }

        public MQTransProducer GetTransProdcuer(string instanceId, string topicName, string groupId)
        {
            if (string.IsNullOrEmpty(topicName))
            {
                throw new MQException("TopicName is null or empty");
            }

            if (string.IsNullOrEmpty(groupId))
            {
                throw new MQException("TopicName is null or empty");
            }

            return new MQTransProducer(instanceId, topicName, groupId, this);
        }
        private ConcurrentDictionary<string, MQConsumer> Consumers;
        public MQConsumer GetConsumer(string instanceId, string topicName, String consumer, String messageTag)
        {
            if (string.IsNullOrEmpty(topicName))
            {
                throw new MQException("TopicName is null or empty");
            }
            if (string.IsNullOrEmpty(consumer))
            {
                throw new MQException("Consumer is null or empty");
            }

            return new MQConsumer(instanceId, topicName, consumer, messageTag, this);
        }
    }
}
