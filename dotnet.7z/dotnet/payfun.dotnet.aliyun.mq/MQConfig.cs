﻿using payfun.dotnet.aliyun.mq.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace payfun.dotnet.aliyun.mq
{
    public class AliyunMQClienOption
    {
        /// <summary>
        /// 设置HTTP接入域名（此处以公共云生产环境为例）
        /// </summary>
        public string Endpoint { get; set; } = "${HTTP_ENDPOINT}";

        /// <summary>
        /// AccessKey 阿里云身份验证，在阿里云服务器管理控制台创建
        /// </summary>
        public string AccessKeyId { get; set; } = "${ACCESS_KEY}";


        /// <summary>
        /// SecretKey 阿里云身份验证，在阿里云服务器管理控制台创建
        /// </summary>
        public string SecretAccessKey { get; set; } = "${SECRET_KEY}";

        /// <summary>
        /// 所属的 Topic
        /// </summary>
        public string TopicName { get; set; } = "${TOPIC}";
        /// <summary>
        /// Topic所属实例ID，默认实例为空
        /// </summary>
        public string InstanceId { get; set; } = "${INSTANCE_ID}";
    }
    public partial class MQConfig : ClientConfig
    {
        public MQConfig()
        {
        }

        public override string ServiceVersion
        {
            get
            {
                return "2015-06-06";
            }
        }

        public override string ServiceName
        {
            get
            {
                return "payfun.dotnet.aliyun.mq";
            }
        }
    }
}
