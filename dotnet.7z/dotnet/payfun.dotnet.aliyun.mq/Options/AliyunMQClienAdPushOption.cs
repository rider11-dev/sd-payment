﻿using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet.aliyun.mq.Options
{
    public class AliyunMQClienAdPushOption
    {
        public string TopicName { get; set; }

        public string InstanceId { get; set; }
    }
}
