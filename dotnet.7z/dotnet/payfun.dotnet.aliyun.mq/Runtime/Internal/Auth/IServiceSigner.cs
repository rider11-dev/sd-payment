﻿using payfun.dotnet.aliyun.mq.Runtime.Internal.Util;

namespace payfun.dotnet.aliyun.mq.Runtime.Internal.Auth
{
    public partial interface IServiceSigner
    {
         void Sign(IRequest request, string accessKeyId, string secretAccessKey, string stsToken);
    }
}
