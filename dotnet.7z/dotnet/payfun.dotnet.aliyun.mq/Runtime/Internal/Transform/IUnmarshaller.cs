﻿namespace payfun.dotnet.aliyun.mq.Runtime.Internal.Transform
{
    public interface IUnmarshaller<T, R>
    {
        T Unmarshall(R input);
    }
}
