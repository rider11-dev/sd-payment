﻿namespace payfun.dotnet.aliyun.mq.Runtime.Internal.Transform
{
    public interface IMarshaller<T, R>
    {
        T Marshall(R input);
    }
}
