﻿using System;
using System.Net;
using payfun.dotnet.aliyun.mq.Runtime;
using payfun.dotnet.aliyun.mq.Runtime.Internal;
using payfun.dotnet.aliyun.mq.Runtime.Internal.Transform;
using payfun.dotnet.aliyun.mq.Util;
using payfun.dotnet.aliyun.mq.Model.Exp;
using System.Xml;

namespace payfun.dotnet.aliyun.mq.Model.Internal.MarshallTransformations
{
    internal class PublishMessageResponseUnmarshaller : XmlResponseUnmarshaller
    {
        public override WebServiceResponse Unmarshall(XmlUnmarshallerContext context)
        {
            XmlTextReader reader = new XmlTextReader(context.ResponseStream);
            PublishMessageResponse response = new PublishMessageResponse();

            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element:
                        switch (reader.LocalName)
                        {
                            case Constants.XML_ELEMENT_MESSAGE_ID:
                                reader.Read();
                                response.MessageId = reader.Value;
                                break;
                            case Constants.XML_ELEMENT_MESSAGE_BODY_MD5:
                                reader.Read();
                                response.MessageBodyMD5 = reader.Value;
                                break;
                            case Constants.XML_ELEMENT_RECEIPT_HANDLE:
                                reader.Read();
                                response.ReeceiptHandle = reader.Value;
                                break;
                        }
                        break;
                }
            }
            reader.Close();
            return response;
        }

        public override AliyunServiceException UnmarshallException(XmlUnmarshallerContext context, Exception innerException, HttpStatusCode statusCode)
        {
            ErrorResponse errorResponse = ErrorResponseUnmarshaller.Instance.Unmarshall(context);
            if (errorResponse.Code != null && errorResponse.Code.Equals(ErrorCodes.TopicNotExist))
            {
                return new TopicNotExistException(errorResponse.Message, innerException, errorResponse.Code, errorResponse.RequestId, errorResponse.HostId, statusCode);
            }
            if (errorResponse.Code != null && errorResponse.Code.Equals(ErrorCodes.MalformedXML))
            {
                return new MalformedXMLException(errorResponse.Message, innerException, errorResponse.Code, errorResponse.RequestId, errorResponse.HostId, statusCode);
            }
            if (errorResponse.Code != null && errorResponse.Code.Equals(ErrorCodes.InvalidArgument))
            {
                return new InvalidArgumentException(errorResponse.Message, innerException, errorResponse.Code, errorResponse.RequestId, errorResponse.HostId, statusCode);
            }
            return new MQException(errorResponse.Message, innerException, errorResponse.Code, errorResponse.RequestId, errorResponse.HostId, statusCode);
        }

        private static PublishMessageResponseUnmarshaller _instance = new PublishMessageResponseUnmarshaller();
        public static PublishMessageResponseUnmarshaller Instance
        {
            get
            {
                return _instance;
            }
        }

    }
}