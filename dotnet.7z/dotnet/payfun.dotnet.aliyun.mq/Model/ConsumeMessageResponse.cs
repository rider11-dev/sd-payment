﻿using payfun.dotnet.aliyun.mq.Model.Internal.MarshallTransformations;
using payfun.dotnet.aliyun.mq.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace payfun.dotnet.aliyun.mq.Model
{
    public partial class ConsumeMessageResponse : WebServiceResponse
    {
        private List<Message> _messages = new List<Message>();

        public List<Message> Messages
        {
            get { return this._messages; }
            set { this._messages = value; }
        }
    }
}
