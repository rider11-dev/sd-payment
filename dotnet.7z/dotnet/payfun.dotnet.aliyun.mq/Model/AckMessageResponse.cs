﻿using payfun.dotnet.aliyun.mq.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using payfun.dotnet.aliyun.mq.Model.Internal.MarshallTransformations;

namespace payfun.dotnet.aliyun.mq.Model
{
    public partial class AckMessageResponse : WebServiceResponse
    {
    }
}
