﻿using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet
{
    public class page<T>
    {
        /// <summary>
        /// 总记录数
        /// </summary>
        public long total_records { get; set; }


        /// <summary>
        /// 当前页
        /// </summary>
        public int current_page { get; set; } = 1;

        private int pageSize = 0;
        /// <summary>
        /// 每页条目数
        /// </summary>
        public int page_size
        {
            get
            {
                if (pageSize <= 0)
                    pageSize = 10;
                return pageSize;
            }
            set
            {
                pageSize = value;
            }
        }


        private int totalPage = 0;
        /// <summary>
        /// 总页数,只读
        /// </summary>
        public int total_page
        {
            get
            {
                if (totalPage == 0)
                {
                    totalPage = (int)total_records / page_size;
                    if ((total_records % page_size) > 0)
                        totalPage++;
                }
                return totalPage;
            }
        }


        /// <summary>
        /// 数据list
        /// </summary>
        public List<T> item_list { get; set; } = new List<T>();
    }
}
