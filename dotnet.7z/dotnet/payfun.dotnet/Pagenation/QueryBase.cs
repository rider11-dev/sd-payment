﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace payfun.dotnet
{
    /// <summary>
    /// 传统分页查询基类,基于表或者视图的查询
    /// </summary>
    public abstract class QueryBase
    {
        #region  分页
        /// <summary>
        /// (不用填写)每页记录数
        /// </summary>
        public int page_size { get; set; } = 10;

        /// <summary>
        /// 当前页面（页号）
        /// </summary>
        public int current_page { get; set; } = 1;

        /// <summary>
        /// (不用填写)开始页码
        /// </summary>
        [IgnoreDataMember]
        [BindNever]
        [JsonIgnore]
        public Int32 start_index
        {
            get { return (current_page - 1) * page_size; }
        }

        /// <summary>
        /// (不用填写)结束页码
        /// </summary>
        [IgnoreDataMember]
        [BindNever]
        [JsonIgnore]
        public Int32 end_index
        {
            get
            {
                return current_page * page_size;
            }
        }
        #endregion

        /// <summary>
        /// (不用填写)需要查询的字段,默认为 * 
        /// </summary>
        [IgnoreDataMember]
        [BindNever]
        [JsonIgnore]
        public virtual string fields { get; set; } = " * ";
        /// <summary>
        /// (不用填写)排序字段 (默认为主键,可以不用填写)
        /// </summary>
        [IgnoreDataMember]
        [BindNever]
        [JsonIgnore]
        public virtual string order_by { get; set; } = "Id";
        /// <summary>
        /// (不用填写)主键
        /// </summary>
        [IgnoreDataMember]
        [BindNever]
        [JsonIgnore]
        public virtual string primary_key { get; set; } = "Id";

        /// <summary>
        /// (不用填写)表名
        /// </summary>
        [IgnoreDataMember]
        [BindNever]
        [JsonIgnore]
        public abstract string table_name { get; set; }

        /// <summary>
        /// 生成Where SQL
        /// </summary>
        /// <returns></returns>
        public abstract string ToSqlString();
    }
}
