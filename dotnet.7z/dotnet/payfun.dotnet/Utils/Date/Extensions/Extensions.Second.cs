﻿using System;

namespace payfun.dotnet.Utils.Date.Extensions
{
    public static partial class DateTimeExtensions
    {
        /// <summary>
        /// 把秒转换成分钟
        /// </summary>
        /// <returns></returns>
        public static int SecondToMinute(long Second)
        {
            if (Second <= 0)
            {
                return 0;
            }
            decimal mm = (Second / (decimal)60);
            return Convert.ToInt32(Math.Ceiling(mm));
        }


        /// <summary>
        /// 把秒转换成小时
        /// </summary>
        /// <returns></returns>
        public static decimal SecondToHour(long Second, int decimals = 1)
        {
            if (Second <= 0)
            {
                return 0;
            }
            decimal h = (Second / (decimal)(60 * 60));
            return Math.Round(h, decimals);
        }
    }
}
