﻿using System;
using System.Globalization;

namespace payfun.dotnet.Utils.Utilities.Date
{
    /// <summary>
    /// 日期时间输出样式
    /// </summary>
    public enum DateTimeOutputStyles
    {
        /// <summary>
        /// 格式：yyyy-MM-dd HH:mm:ss
        /// </summary>
        DateTime,
        /// <summary>
        /// 格式：yyyy-MM-dd
        /// </summary>
        Date,
        /// <summary>
        /// 格式：HH:mm:ss
        /// </summary>
        Time,
        /// <summary>
        /// 长日期。格式：yyyy年MM月dd日
        /// </summary>
        LongDate,
        /// <summary>
        /// 长时间。格式：HH:mm:ss
        /// </summary>
        LongTime,
        /// <summary>
        /// 短日期。格式：yyyy/MM/dd
        /// </summary>
        ShortDate,
        /// <summary>
        /// 短时间。格式：HH:mm
        /// </summary>
        ShortTime,
        /// <summary>
        /// 格式：yyyy-MM-dd HH:mm:ss.fff
        /// </summary>
        Millisecond,
    }


    /// <summary>
    /// 日期时间转字符串 扩展
    /// </summary>
    public static class DateTimeToStringExtensions
    {
        /// <summary>
        /// 转换为字符串
        /// </summary>
        /// <param name="dt">日期时间</param>
        /// <param name="styles">日期时间输出样式</param>
        /// <param name="isRemoveSecond">是否移除秒。true:是,false:否</param>
        public static string ToString(this DateTime dt, DateTimeOutputStyles styles, bool isRemoveSecond = false)
        {
            switch (styles)
            {
                case DateTimeOutputStyles.DateTime:
                    return dt.ToString(isRemoveSecond ? "yyyy-MM-dd HH:mm" : "yyyy-MM-dd HH:mm:ss");
                case DateTimeOutputStyles.Date:
                    return dt.ToString("yyyy-MM-dd");
                case DateTimeOutputStyles.Time:
                    return dt.ToString(isRemoveSecond ? "HH:mm" : "HH:mm:ss");
                case DateTimeOutputStyles.LongDate:
                    return dt.ToLongDateString();
                case DateTimeOutputStyles.LongTime:
                    return dt.ToLongTimeString();
                case DateTimeOutputStyles.ShortDate:
                    return dt.ToShortDateString();
                case DateTimeOutputStyles.ShortTime:
                    return dt.ToShortTimeString();
                case DateTimeOutputStyles.Millisecond:
                    return dt.ToString("yyyy-MM-dd HH:mm:ss.fff");
                default:
                    return dt.ToString(CultureInfo.InvariantCulture);
            }
        }

        /// <summary>
        /// 转换为字符串
        /// </summary>
        /// <param name="dt">日期时间</param>
        /// <param name="styles">日期时间输出样式</param>
        /// <param name="isRemoveSecond">是否移除秒。true:是,false:否</param>
        public static string ToString(this DateTime? dt, DateTimeOutputStyles styles, bool isRemoveSecond = false) => dt is null ? string.Empty : dt.Value.ToString(styles, isRemoveSecond);

        /// <summary>
        /// 将时间转换为时间点
        /// </summary>
        /// <param name="localDateTime">DateTime</param>
        public static DateTimeOffset ToDateTimeOffset(this DateTime localDateTime) => localDateTime.ToDateTimeOffset(null);

        /// <summary>
        /// 将时间转换为时间点
        /// </summary>
        /// <param name="localDateTime">DateTime</param>
        /// <param name="localTimeZone">时区</param>
        public static DateTimeOffset ToDateTimeOffset(this DateTime localDateTime, TimeZoneInfo localTimeZone)
        {
            if (localDateTime.Kind != DateTimeKind.Unspecified)
                localDateTime = new DateTime(localDateTime.Ticks, DateTimeKind.Unspecified);
            return TimeZoneInfo.ConvertTime(localDateTime, localTimeZone ?? TimeZoneInfo.Local);
        }

        /// <summary>
        /// 将时间点转换为时间
        /// </summary>
        /// <param name="dateTimeUtc">DateTimeOffset</param>
        public static DateTime ToLocalDateTime(this DateTimeOffset dateTimeUtc) => dateTimeUtc.ToLocalDateTime(null);

        /// <summary>
        /// 将时间点转换为时间
        /// </summary>
        /// <param name="dateTimeUtc">DateTimeOffset</param>
        /// <param name="localTimeZone">时区</param>
        public static DateTime ToLocalDateTime(this DateTimeOffset dateTimeUtc, TimeZoneInfo localTimeZone) => TimeZoneInfo.ConvertTime(dateTimeUtc, localTimeZone ?? TimeZoneInfo.Local).DateTime;

    }
}
