﻿using Dapper;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace payfun.dotnet
{
    public static class DbContextExtension
    {
        public static async Task<List<T>> FromSqlAsync<T>(this DbContext db, string sql)
        {
            var connection = db.Database.GetDbConnection();
            try
            {
                if (connection.State != ConnectionState.Open)
                    await connection.OpenAsync().ConfigureAwait(false);

                var result = await connection.QueryAsync<T>(sql);

                return result.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }

        }


        public static async Task<List<T>> FromSqlAsync<T>(this DbContext db, string sql, DynamicParameters sqlParameters)
        {
            var connection = db.Database.GetDbConnection();
            try
            {
                if (connection.State != ConnectionState.Open)
                    await connection.OpenAsync().ConfigureAwait(false);

                var result = await connection.QueryAsync<T>(sql, sqlParameters);

                return result.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }

        }



        public static async Task<int> ExecuteSqlCommandAsync(this DbContext db, string sql)
        {
            var connection = db.Database.GetDbConnection();
            try
            {
                if (connection.State != ConnectionState.Open)
                    await connection.OpenAsync().ConfigureAwait(false);

                return await connection.ExecuteAsync(sql);
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }

        }


        public static async Task<page<T>> QueryAsync<T>(this DbContext db, QueryBase query) where T : class, new()
        {
            var connection = db.Database.GetDbConnection();
            try
            {
                var page = new page<T>();

                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"SELECT COUNT(1) FROM (select {query.primary_key} from {query.table_name}  {query.ToSqlString()}) t;");

                sb.AppendLine($" select  {query.fields}  from  {query.table_name}   {query.ToSqlString()}  ");
                sb.AppendLine($"  order by {query.order_by} ");
                sb.AppendLine($" limit {query.start_index },{query.page_size} ");


                if (connection.State != ConnectionState.Open)
                    await connection.OpenAsync().ConfigureAwait(false);

                using (var reader = connection.QueryMultiple(sb.ToString()))
                {
                    page.total_records = reader.ReadFirst<int>();
                    page.item_list = reader.Read<T>().ToList();
                    page.current_page = query.current_page;
                    page.page_size = query.page_size;
                }

                return page;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
