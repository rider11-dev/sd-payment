﻿using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet
{
    public static class DateExtension
    {
        /// <summary>
        /// 当前日期的最小时间
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static DateTime TodayBegin(this DateTime date)
        {
            return new DateTime(date.Year, date.Month, date.Day, 0, 0, 0);
        }

        /// <summary>
        /// 当前日期的最大时间
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static DateTime TodayEnd(this DateTime date)
        {
            return new DateTime(date.Year, date.Month, date.Day, 23, 59, 59);
        }

        private static readonly DateTime Default = new DateTime(1999, 1, 1);

        /// <summary>
        /// 默认日期,1999-01-01
        /// </summary>
        public static DateTime DefaultDate
        {
            get
            {
                return Default;
            }
        }

        /// <summary>
        /// 比较两个日期是否相等,精确到秒
        /// </summary>
        /// <param name="date1"></param>
        /// <param name="date2"></param>
        /// <returns></returns>
        public static bool Equals(DateTime date1, DateTime date2)
        {
            return date1.ToString("yyyy-MM-dd HH:mm:ss").Equals(date2.ToString("yyyy-MM-dd HH:mm:ss"));
        }

        /// <summary>
        /// 格式化日期
        /// </summary>
        /// <param name="date"></param>
        /// <param name="format"></param>
        /// <returns></returns>
        public static string Format(this DateTime date, string format = "yyyy-MM-dd HH:mm:ss")
        {
            return date.ToString(format);
        }

        /// <summary>
        /// 比较日期大小，精确到日
        /// </summary>
        /// <param name="dt1"></param>
        /// <param name="dt2"></param>
        /// <returns>dt1-dt2</returns>
        public static int Compare(DateTime dt1, DateTime dt2)
        {
            dt1 = TodayBegin(dt1);
            dt2 = TodayBegin(dt2);
            return DateTime.Compare(dt1, dt2);
        }

        /// <summary>
        /// 时间戳转为C#格式时间
        /// </summary>
        /// <param name="timeStamp">Unix时间戳格式</param>
        /// <returns>C#格式时间</returns>
        public static DateTime GetTime(string timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            long lTime = long.Parse(timeStamp + "0000");
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }

        /// <summary>
        /// 将日期与时间转换成时间戳
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static long GetTimestamp(this System.DateTime date)
        {
            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1, 0, 0, 0, 0));
            long t = (date.Ticks - startTime.Ticks) / 10000;   //除10000调整为13位      
            return t;
        }

    }
}
