﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace payfun.dotnet
{
    public class EnumMember
    {
        public string Description { get; set; }

        public string Name { get; set; }

        public int Value { get; set; }

        public bool IsSelected { get; set; }
    }

    public static class EnumMemberCache
    {
        public static ConcurrentDictionary<string, List<EnumMember>> Cache = new ConcurrentDictionary<string, List<EnumMember>>();
    }

    /// <summary>
    /// 将枚举转换成List,可频繁使用
    /// </summary>
    public static class EnumsList
    {
        /// <summary>
        /// 枚举类型
        /// </summary>
        /// <param name="enumType"></param>
        /// <returns></returns>
        public static List<EnumMember> ToList(Type enumType, object selectValue = null)
        {
            if (!enumType.IsEnum)
                return new List<EnumMember>();
            //if (EnumMemberCache.Cache.ContainsKey(enumType.FullName))
            //    return EnumMemberCache.Cache[enumType.FullName];


            var enumValues = Enum.GetValues(enumType);

            var source = (
                from object enumValue in enumValues
                select new EnumMember
                {
                    Value = Convert.ToInt32(enumValue),
                    Description = GetDescription(enumValue, enumType),
                    Name = Enum.GetName(enumType, enumValue),

                }).ToList();

            if (selectValue != null)
            {
                source.ForEach(p =>
                {
                });
            }

            EnumMemberCache.Cache.TryAdd(enumType.FullName, source);
            return source;
        }

        public static string GetDescription(object enumValue, Type enumType)
        {
            var name = enumValue.GetType().FullName;
            if (name != enumType.FullName)
                throw new Exception("枚举类型不一致");

            var descriptionAttribute = enumType
              .GetField(enumValue.ToString())
              .GetCustomAttributes(typeof(DescriptionAttribute), false)
              .FirstOrDefault() as DescriptionAttribute;


            return descriptionAttribute != null
              ? descriptionAttribute.Description
              : enumValue.ToString();
        }
    }
}
