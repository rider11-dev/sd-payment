﻿using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace payfun.dotnet
{
    public static class ObjectExtension
    {

        /// <summary>
        /// 设置可以Property的值
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <param name="source"></param>
        public static void SetProperty<T>(this T entity, T source) where T : class
        {
            if (entity == null)
                throw new Exception("entity is Null");

            PropertyInfo[] properties = typeof(T).GetProperties();
            foreach (var item in properties)
            {
                if (item.CanWrite)
                {
                    object value = item.GetValue(source);
                    item.SetValue(entity, value);
                }
            }
        }


        /// <summary>
        /// 设置可以Property的值
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <param name="source"></param>
        public static void SetProperty(this object entity, string propertyName, object value)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));

            PropertyInfo[] properties = entity.GetType().GetProperties();
            var property = properties.FirstOrDefault(p => p.Name.Equals(propertyName, StringComparison.CurrentCultureIgnoreCase));
            if (property != null && property.CanWrite)
                property.SetValue(entity, value);
        }

        /// <summary>
        /// 判断对象是否含有指定属性
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public static bool HasProperty(this object entity, string propertyName)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));

            PropertyInfo[] properties = entity.GetType().GetProperties();
            return properties.Any(p => p.Name.Equals(propertyName, StringComparison.CurrentCultureIgnoreCase));

        }
        /// <summary>
        /// 深度复制一个对象,该对象需要被标记Serializable
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="input"></param>
        /// <returns></returns>
        public static T DeepClone<T>(T input) where T : class, new()
        {
            T t = default(T);
            BinaryFormatter formatter = new BinaryFormatter(null, new StreamingContext(StreamingContextStates.Clone));

            using (MemoryStream stream = new MemoryStream())
            {
                formatter.Serialize(stream, input);
                stream.Position = 0;
                t = formatter.Deserialize(stream) as T;
            }
            return t;
        }

        public static string ToJson(this object o)
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(o);
        }
        public static string ToJson(this object o, JsonConverter jsonConverter)
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(o, jsonConverter);
        }

        /// <summary>
        /// 转换bool,失败则返回输入的默认值
        /// </summary>
        /// <param name="source"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static bool ToBoolean(this object source, bool defaultValue)
        {
            if (source == null || Convert.IsDBNull(source))
                return defaultValue;

            bool value;

            if (bool.TryParse(source.ToString(), out value))
                return value;

            return defaultValue;
        }

        /// <summary>
        ///转换Int16,失败则返回输入的默认值
        /// </summary>
        /// <returns>Short</returns>
        public static short ToInt16(this object source, Int16 defaultValue)
        {
            if (source == null || Convert.IsDBNull(source))
                return defaultValue;

            short reValue;
            if (short.TryParse(source.ToString(), out reValue))
                return reValue;

            return defaultValue;
        }
        /// <summary>
        ///转换Int32,失败则返回输入的默认值
        /// </summary>
        /// <returns>Short</returns>
        public static int ToInt32(this object source, Int32 defaultValue)
        {
            if (source == null || Convert.IsDBNull(source))
                return defaultValue;

            int reValue;
            if (int.TryParse(source.ToString(), out reValue))
                return reValue;

            return defaultValue;
        }
        /// <summary>
        /// 转化为int64,失败则返回输入的默认值
        /// </summary>
        /// <returns>int64</returns>
        public static long ToInt64(this object source, Int64 defaultValue)
        {
            if (source == null || Convert.IsDBNull(source))
                return defaultValue;

            long reValue;
            if (Int64.TryParse(source.ToString(), out reValue))
                return reValue;

            return defaultValue;
        }

        /// <summary>
        /// 转化为decimal,失败则返回输入的默认值
        /// </summary>
        /// <returns>decimal</returns>
        public static decimal ToDecimal(this object source, decimal defaultValue)
        {
            if (source == null || Convert.IsDBNull(source))
                return defaultValue;

            decimal reValue;
            if (decimal.TryParse(source.ToString(), out reValue))
                return reValue;

            return defaultValue;
        }


        /// <summary>
        /// 转化为Double,失败则返回输入的默认值
        /// </summary>
        /// <returns>decimal</returns>
        public static Double ToDouble(this object source, double defaultValue)
        {
            if (source == null || Convert.IsDBNull(source))
                return defaultValue;

            Double reValue;
            if (Double.TryParse(source.ToString(), out reValue))
                return reValue;

            return defaultValue;
        }

        /// <summary>
        /// 转化为Double,失败则返回输入的默认值
        /// </summary>
        /// <returns>decimal</returns>
        public static DateTime ToDateTime(this object source, DateTime defaultValue)
        {
            if (source == null || Convert.IsDBNull(source))
                return defaultValue;

            DateTime reValue;
            if (DateTime.TryParse(source.ToString(), out reValue))
                return reValue;

            return defaultValue;
        }
    }
}
