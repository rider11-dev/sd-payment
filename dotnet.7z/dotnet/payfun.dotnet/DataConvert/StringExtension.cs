﻿using Newtonsoft.Json;
using System;
using System.Text;
using System.Text.RegularExpressions;

namespace payfun.dotnet
{
    public static class StringExtension
    {
        public static bool IsNullOrEmpty(this string value)
        {
            return string.IsNullOrWhiteSpace(value);
        }
        public static bool NotNullOrEmpty(this string value)
        {
            if (value.IsNullOrEmpty())
                return false;

            return true;
        }

        public static bool IsMobilePhone(this string source)
        {
            if (string.IsNullOrEmpty(source))
                return false;
            return Regex.IsMatch(source, @"^0{0,1}(1[3,5,8][0-9]|14[5,7]|17[0,6,7,8])[0-9]{8}$", RegexOptions.Compiled);
        }

        public static bool IsEmail(this string source)
        {
            return source.Contains("@");
        }

        public static bool IsNetworkPath(this string urlStr)
        {
            return Regex.IsMatch(urlStr, @"((http|ftp|https)://)(([a-zA-Z0-9\._-]+\.[a-zA-Z]{2,6})|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,4})*(/[a-zA-Z0-9\&%_\./-~-]*)?", RegexOptions.Compiled);
        }

        public static bool ToBoolean(this string source, bool defaultValue)
        {
            bool value;
            if (bool.TryParse(source, out value))
                return value;

            return defaultValue;
        }
        public static int ToInt32(this string source, Int32 defaultValue)
        {
            int reValue;
            if (int.TryParse(source, out reValue))
                return reValue;

            return defaultValue;
        }

        public static long ToInt64(this string source, Int64 defaultValue)
        {
            long reValue;
            if (Int64.TryParse(source, out reValue))
                return reValue;

            return defaultValue;
        }

        public static decimal ToDecimal(this string source, decimal defaultValue)
        {
            decimal reValue;
            if (decimal.TryParse(source, out reValue))
                return reValue;

            return defaultValue;
        }

        public static Double ToInt32(this string source, double defaultValue)
        {
            Double reValue;
            if (Double.TryParse(source, out reValue))
                return reValue;

            return defaultValue;
        }

        /// <summary>
        /// 获取字符串长度，按中文2位，英文1位进行计算
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static int CharCodeLength(this string source)
        {
            int n = 0;
            foreach (var c in source.ToCharArray())
                if ((int)c < 128)
                    n++;
                else
                    n += 2;
            return n;
        }

        /// <summary>
        /// 将字符串转换成Base64,默认UTF8编码
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToBase64(this string value, Encoding encoding = null)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "";

            Encoding e = null;
            if (encoding == null)
                e = Encoding.UTF8;
            else
                e = encoding;

            var bytes = e.GetBytes(value);
            return Convert.ToBase64String(bytes);
        }

        /// <summary>
        /// 讲base64转换成字符串,默认UTF8编码
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string FromBase64(this string value, Encoding encoding = null)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "";

            var bytes = Convert.FromBase64String(value);
            Encoding e = null;
            if (encoding == null)
                e = Encoding.UTF8;
            else
                e = encoding;

            return e.GetString(bytes);
        }



        /// <summary>
        /// 将该字符串转换成byte[],默认UTF8编码
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[] ToBytes(this string value, Encoding encoding = null)
        {
            if (encoding == null)
                return Encoding.UTF8.GetBytes(value);

            return encoding.GetBytes(value);
        }
        public static T FromJson<T>(this string value)
        {
            if (value.IsNullOrEmpty())
                return default(T);

            return JsonConvert.DeserializeObject<T>(value);
        }


        /// <summary>
        /// 比较是否相等,忽略大小写
        /// </summary>
        /// <param name="value"></param>
        /// <param name="input"></param>
        /// <returns></returns>
        public static bool Equal(this string value, string input)
        {
            if (value == null && input == null)
                return true;

            if (value == null && input != null)
                return false;


            return value.Equals(input, StringComparison.CurrentCultureIgnoreCase);
        }

        public static void RemoveLast(this StringBuilder sb)
        {
            sb.Remove(sb.Length - 1, 1);
        }
    }
}
