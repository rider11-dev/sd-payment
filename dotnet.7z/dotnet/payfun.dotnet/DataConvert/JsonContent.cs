﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace payfun.dotnet
{
    public class JsonContent : StringContent
    {
        public JsonContent(object data) : base(data.ToJson(), Encoding.UTF8, "application/json")
        {

        }
    }
}
