﻿using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet
{
    public class HttpResult
    {
        public int code { get; set; }
        public string message { get; set; }

        public object data { get; set; }

        public static HttpResult Ok(string msg = "操作成功", object data = null)
        {
            return new HttpResult { code = 200, message = msg, data = data };
        }
        public static HttpResult Error(string msg = "操作失败", object data = null)
        {
            return new HttpResult { code = 400, message = msg, data = data };
        }
    }
}
