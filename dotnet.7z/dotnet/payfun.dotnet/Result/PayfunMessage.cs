﻿using System;
using System.Collections.Generic;
using System.Text;

namespace payfun.dotnet
{
    public class PayfunMessage : Exception
    {
        public int code { get; set; }
        public PayfunMessage(string msg, int code = 400) : base(msg)
        {
            this.msg = msg;
            this.code = code;
        }

        public string msg { get; set; }

        public HttpResult ToHttpResult()
        {
            return new HttpResult { code = this.code, message = this.msg };
        }
    }
}
